#pragma once

extern const char* icosphereObjData;
